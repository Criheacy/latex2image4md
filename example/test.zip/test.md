test formula 1: empty ![4](./test-asset/4.svg)

test formula 2-1: inlined ![5](./test-asset/5.svg)​ formula

test formula 2-2: inlined ![6](./test-asset/6.svg) formula

test formula 3: block formula ![1](./test-asset/1.svg) this

test formula 4: start of a line

![7](./test-asset/7.svg)

test formula 5-1: block
![2](./test-asset/2.svg)


test formula 5-2: block
![3](./test-asset/3.svg)